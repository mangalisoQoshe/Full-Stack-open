function Part({ part, exercise }) {
  return (
    <p>
      {part} {exercise}
    </p>
  );
}

export default Part;
