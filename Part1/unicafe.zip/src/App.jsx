import { useState } from "react";
import "./App.css";
import Statistics from "./assets/Statistics";
import Button from "./assets/Button";

function App() {
  const [good, setGood] = useState(0);
  const [neutral, setNeutral] = useState(0);
  const [bad, setBad] = useState(0);

  const handleButton = (feedback) => {
    switch (feedback) {
      case "good":
        return () => {
          setGood((prevGood) => prevGood + 1);
        };

      case "neutral":
        return () => {
          setNeutral((prevNeutral) => prevNeutral + 1);
        };

      default:
        return () => {
          setBad((prevBad) => prevBad + 1);
        };
    }
  };

  let totalFeedback = good + neutral + bad;
  let avgScore = (good - bad) / totalFeedback;
  let positive = (good / totalFeedback) * 100;

  return (
    <div>
      <h1>Give feedback</h1>

      <div>
        <Button onClickBtn={handleButton("good")} name="good" />
        <Button onClickBtn={handleButton("neutral")} name="neutral" />
        <Button onClickBtn={handleButton("bad")} name="bad" />
      </div>

      <Statistics
        totalFeedback={totalFeedback}
        avgScore={avgScore}
        positive={positive}
        good={good}
        bad={bad}
        neutral={neutral}
      />
    </div>
  );
}

export default App;
