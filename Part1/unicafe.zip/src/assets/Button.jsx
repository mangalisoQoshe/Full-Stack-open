function Button({ name, onClickBtn }) {
  return <button onClick={onClickBtn}>{name}</button>;
}

export default Button;
