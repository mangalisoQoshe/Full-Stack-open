function StatisticLine({ stats, text }) {
  return (
    <tr>
      <td>{text}</td>
      <td>{stats}</td>
    </tr>
  );
}

export default StatisticLine;
