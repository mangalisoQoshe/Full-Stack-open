import StatisticLine from "./StatisticLine";

function Statistics({ good, neutral, bad, totalFeedback, avgScore, positive }) {
  return (
    <div>
      <h1>Statistics</h1>
      {totalFeedback === 0 ? (
        <p>No feedback give</p>
      ) : (
        <table>
          <tbody>
            <StatisticLine text="good" stats={good} />
            <StatisticLine text="neutral" stats={neutral} />
            <StatisticLine text="bad" stats={bad} />
            <StatisticLine text="totalFeedback" stats={totalFeedback} />
            <StatisticLine text="avgScore" stats={avgScore} />
            <StatisticLine text="positive" stats={positive + " %"} />
          </tbody>
        </table>
      )}
    </div>
  );
}

export default Statistics;
