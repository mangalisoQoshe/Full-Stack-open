const Header = ({ name }) => <h1>{name}</h1>;
export default Header;
