import "./App.css";
import { useEffect, useState } from "react";
import axios from "axios";
import Display from "./components/Display";


function App() {
  const [countries, setCountries] = useState([]);
  const [search, setSearch] = useState(null);
  const [filteredList, setFilterdList] = useState([]);

  useEffect(() => {
    axios
      .get("https://studies.cs.helsinki.fi/restcountries/api/all")
      .then((response) => {
        setCountries(response.data);
      });
  }, []);

  useEffect(() => {
    onSearch();
  }, [search]);

  const handleChange = (e) => {
    setSearch(e.target.value);
  };

  const onSearch = () => {
    if (search) {
      setFilterdList(
        countries.filter((country) => {
          return country.name.common
            .toLowerCase()
            .includes(search.toLowerCase());
        })
      );
    }
  };

  return (
    <div>
     
      <form>
        <label htmlFor="country">Find countries</label>
        <input type="text" id="country" onChange={handleChange} />
      </form>
      {filteredList && <Display filteredList={filteredList} />}
    </div>
  );
}

export default App;
