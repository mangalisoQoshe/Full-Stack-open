import WeatherData from "./WeatherData";

function CountryView({ country }) {
  return (
    <div>
      <h1>{country.name.common}</h1>
      <p>Capital {country.capital}</p>
      <p>Area {country.area}</p>
      <div>
        <h3>Languages</h3>
        <ul>
          {Object.keys(country.languages).map((key) => (
            <li key={key}>{country.languages[key]}</li>
          ))}
        </ul>
      </div>
      <div>
        <img src={country.flags["png"]} alt={country.flags["alt"]} />
      </div>
      <WeatherData city={country.capital} />
    </div>
  );
}

export default CountryView;
