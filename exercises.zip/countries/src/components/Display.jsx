import { useState } from "react";
import CountryView from "./CountryView";


function Display({ filteredList }) {
  const [viewCountry, setViewCountry] = useState(null);
 
  if (filteredList.length > 10) {
    return <div> Too many matches, specify another filter</div>;
  } else if (filteredList.length === 1) {
    return <CountryView country={filteredList[0]} />;
  }
  

  const handleShow = (item) => {
    setViewCountry(item);
  };
  return (
    <div>
      <ul>
        {filteredList.map((item) => (
          <li key={item.altSpellings[0]}>
            {item.name.common}{" "}
            <button
              onClick={() => {
                handleShow(item);
              }}
            >
              Show
            </button>
          </li>
        ))}
      </ul>
      {viewCountry && <CountryView country={viewCountry} />}
    </div>
  );
}

export default Display;
