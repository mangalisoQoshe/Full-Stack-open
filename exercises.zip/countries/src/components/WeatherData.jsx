import axios from "axios";
import { useEffect, useState } from "react";

function WeatherData({ city }) {
  const [weatherData, setWeatherData] = useState(null);
  useEffect(() => {
    const apiKey = import.meta.env.VITE_weather_api_key;
    const apiUrl = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`;
    axios.get(apiUrl).then((response) => {
      setWeatherData(response.data);
    });
  }, [city]);
 
  return weatherData ? (
    <div>
      <h2>{weatherData.name}</h2>
      <p>{weatherData.weather[0].description}</p>
      <p>Temperature: {weatherData.main.temp} °C</p>
      <img src={` https://openweathermap.org/img/wn/${weatherData.weather[0].icon}@2x.png`} alt="weather icon" />
      <p>Wind {weatherData.wind.speed} m/s</p>
    </div>
  ) : (
    <p>Loading weather data...</p>
  );
}

export default WeatherData;
