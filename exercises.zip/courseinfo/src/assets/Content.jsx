import Part from "./Part";


const Content = ({ parts }) => {
  const list = parts.map((part) => <Part key={part.id} part={part} />);

  return <> {list}</>;
};

export default Content;

