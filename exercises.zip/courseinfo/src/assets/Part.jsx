

const Part = ({ part }) => (
  <p>
    {part.name} {part.exercises}
  </p>
);
export default Part;
