

function Total({ parts }) {
  const total = parts.reduce((accumulator, currentPart) => {
    return accumulator + currentPart.exercises;
  },0);
  return <p> <strong>total of {total} exercises</strong></p>;
}

export default Total;
