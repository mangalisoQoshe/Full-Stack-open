import "./App.css";
import Notification from "./components/Notification";
import personService from "./services/Person";
import { useEffect, useState } from "react";

const App = () => {
  const [persons, setPersons] = useState([]);
  const [newPerson, setNewPerson] = useState({ newName: "", newNumber: "" });
  const [filteredText, setFilteredText] = useState("");
  const [notify, setNotify] = useState("");

  useEffect(() => {
    personService
      .getAll()
      .then((initialPersons) => {
        setPersons(initialPersons);
      })
      .catch((err) => {
        console.log("Server Offline");
      });
  }, []);

  const deletePerson = ({ id, name }) => {
    if (window.confirm(`Delete ${name}`)) {
      personService.deleteObj(id).then(() => {
        setPersons(persons.filter((person) => person.id !== id));
      });
    }
  };

  const addPerson = (event) => {
    event.preventDefault();

    if (checkNameExist(newPerson.newName)) {
      if (
        window.confirm(
          `${newPerson.newName} is already added to phonebook, replace the old number with a new one?`
        )
      ) {
        const person = persons.find((p) => p.name === newPerson.newName);
        const newP = { ...person, number: newPerson.newNumber };
        personService
          .update(newP.id, newP)
          .then((returnedPerson) => {
            setPersons(
              persons.map((person) =>
                person.id !== newP.id ? person : returnedPerson
              )
            );

            setNotify("success");

            setTimeout(() => {
              setNotify("");
              setNewPerson({ newName: "", newNumber: "" });
            }, 5000);
          })
          .catch((err) => {
            setNotify("error");
            setTimeout(() => {
              setNotify("");
            }, 5000);
          });
      }
      return;
    }

    const personObj = {
      name: newPerson.newName,
      number: newPerson.newNumber,
    };

    personService.create(personObj).then((returnedPerson) => {
      setPersons(persons.concat(returnedPerson));
      setNotify("success");
      setTimeout(() => {
        setNotify("");
        setNewPerson({ newName: "", newNumber: "" });
      }, 5000);
    });
  };

  const checkNameExist = (name) => {
    return persons.some((person) => person.name === name);
  };

  return (
    <div>
      <h2>Phonebook</h2>
      <Notification message={notify} name={newPerson.newName} />
      <div>
        filter shown with
        <input
          type="text"
          value={filteredText}
          onChange={(e) => setFilteredText(e.target.value)}
        />
      </div>
      <h2>add a new</h2>
      <form onSubmit={addPerson}>
        <div>
          name:
          <input
            value={newPerson.newName}
            onChange={(event) =>
              setNewPerson({ ...newPerson, newName: event.target.value })
            }
          />
        </div>
        <div>
          number:
          <input
            value={newPerson.newNumber}
            type="number"
            onChange={(event) =>
              setNewPerson({ ...newPerson, newNumber: event.target.value })
            }
          />
        </div>
        <div>
          <button type="submit">add</button>
        </div>
      </form>
      <h2>Numbers</h2>
      <div>
        {filteredText === ""
          ? persons.map((person) => (
              <div key={person.id}>
                {person.name} {person.number}{" "}
                <button
                  onClick={() => {
                    deletePerson(person);
                  }}
                >
                  delete
                </button>
              </div>
            ))
          : persons
              .filter((person) => {
                return (
                  person.name.toLowerCase() === filteredText.toLocaleLowerCase()
                );
              })
              .map((person) => (
                <div key={person.id}>
                  {person.name} {person.number}
                </div>
              ))}
      </div>
    </div>
  );
};

export default App;
