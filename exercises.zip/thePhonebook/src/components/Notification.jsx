import styles from "./Notification.module.css";

function Notification({ message, name }) {
  switch (message) {
    case "success":
      return <div className={styles.success}>Added {name}</div>;
    case "error":
      return (
        <div className={styles.error}>
          Information of {name} has already been removed from the server
        </div>
      );

    default:
      return null;
  }
}

export default Notification;
